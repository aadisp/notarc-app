"use client";

import {
  Package,
  ShoppingCart,
  GraduationCap,
  Users,
} from "lucide-react";
import { uploadToCloudinary } from "@/lib/cloudinary";
import CourseTable from "@/components/admin/courses/course-table";
import CourseForm from "@/components/admin/courses/course-form";
import AddCourseDialog from "@/components/admin/courses/add-course-dialog";
import { toast } from "sonner";
import ProductTable from "@/components/admin/products/product-table";
import ProductForm from "@/components/admin/product-form";
import AdminNav from "@/components/admin/admin-nav";
import DashboardCard from "@/components/admin/dashboard-card";

import SiteLayout from "@/components/layout/site-layout";
import { useEffect, useState } from "react";
import AddProductDialog from "@/components/admin/products/add-product-dialog";
import {
  addDoc,
  collection,
  getCountFromServer,
} from "firebase/firestore";
import { db } from "@/firebase/firebase";
import { useUserRole } from "@/hooks/use-user-role";
import { products } from "@/data/products";

export default function AdminPage() {
  const role = useUserRole();

  const [name, setName] =
    useState("");

  const [category, setCategory] =
    useState("");

  const [price, setPrice] =
    useState("");

  const [description, setDescription] =
    useState("");

  const [
    longDescription,
    setLongDescription,
  ] = useState("");

  const [courseName, setCourseName] =
  useState("");

  const [courseLevel, setCourseLevel] =
    useState("");

  const [courseDuration, setCourseDuration] =
    useState("");

  const [courseDescription,
    setCourseDescription] =
    useState("");

  const [
      courseLongDescription,
      setCourseLongDescription,
  ] = useState("");

  const [productFiles,
    setProductFiles] =
    useState<File[]>([]);

  const [courseFile,
    setCourseFile] =
    useState<File | null>(null);

  const [productCount,
    setProductCount] =
    useState(0);

  const [courseCount,
    setCourseCount] =
    useState(0);

  const [orderCount,
    setOrderCount] =
    useState(0);

  const [userCount,
    setUserCount] =
    useState(0);

  const [addProductOpen, setAddProductOpen] =
    useState(false);

  const [addCourseOpen, setAddCourseOpen] =
    useState(false);

  const [addingProduct, setAddingProduct] =
    useState(false);

const [addingCourse, setAddingCourse] =
    useState(false);

  async function handleAddProduct() {
    setAddingProduct(true);
  try {

    const imageUrls: string[] = [];
    const publicIds: string[] = [];

    for (const file of productFiles) {

      const upload = await uploadToCloudinary(file);

      imageUrls.push(upload.imageUrl);
      publicIds.push(upload.publicId);

    }

    await addDoc(collection(db, "products"), {

      name,

      slug: name
        .toLowerCase()
        .replace(/\s+/g, "-"),

      category,

      price: Number(price),

      description,
      longDescription,

      imageUrls,

      publicIds,

    });

    setLongDescription("");

    toast.success("Product added successfully!");

    setName("");
    setCategory("");
    setPrice("");
    setDescription("");

    setProductFiles([]);

  } catch (error) {

    console.error(error);

    toast.error("Failed to add product.");

}
finally {

    setAddingProduct(false);

}
  }

  async function importDefaultProducts() {
    try {
      for (const product of products) {
        await addDoc(
          collection(db, "products"),
          {
            name: product.name,
            slug: product.slug,
            category: product.category,
            price: product.price,
            description:
              product.description,
            imageUrls: [],
            publicIds: [],
          }
        );
      }

      toast.success("Products imported");
    } catch (error) {
      console.error(error);
    }
  }



  async function handleAddCourse() {
    setAddingCourse(true);
    try {
      let uploadedImageUrl = "";
      let uploadedPublicId = "";

      if (courseFile) {
          const { imageUrl, publicId } =
              await uploadToCloudinary(courseFile);

          uploadedImageUrl = imageUrl;
          uploadedPublicId = publicId;
      }
      await addDoc(
        collection(db, "courses"),
        {
          name: courseName,
          slug: courseName
            .toLowerCase()
            .replace(/\s+/g, "-"),
          level: courseLevel,
          duration: courseDuration,
          description:
            courseDescription,
          longDescription: courseLongDescription,
          imageUrl:
            uploadedImageUrl,
          publicId: uploadedPublicId,
        }
      );

      toast.success("Course added successfully!");

      setCourseName("");
      setCourseLevel("");
      setCourseDuration("");
      setCourseDescription("");
      setCourseLongDescription("");
      setCourseFile(null);
    } catch (error) {

    console.error(error);

    toast.error("Failed to add course.");

}
finally {

    setAddingCourse(false);

}
  }

  useEffect(() => {

    async function loadCounts() {

      const products =
        await getCountFromServer(
          collection(
            db,
            "products"
          )
        );

      const courses =
        await getCountFromServer(
          collection(
            db,
            "courses"
          )
        );

      const orders =
        await getCountFromServer(
          collection(
            db,
            "orders"
          )
        );

      const users =
        await getCountFromServer(
          collection(
            db,
            "users"
          )
        );

      setProductCount(
        products.data().count
      );

      setCourseCount(
        courses.data().count
      );

      setOrderCount(
        orders.data().count
      );

      setUserCount(
        users.data().count
      );

    }

    if (role === "admin") {
      loadCounts();
    }

  }, [role]);

  if (role !== "admin") {
    return (
      <main className="p-10">
        Access Denied
      </main>
    );
  }

  return (

    <SiteLayout>

      <main className="mx-auto max-w-7xl px-6 py-24">

      <div className="mb-12">

        <h1 className="mb-8 text-5xl font-bold">
          Dashboard
        </h1>

        <AdminNav />

        <p className="mt-3 text-slate-500">
          Manage orders, products and courses from one place.
        </p>

      </div>

      <div
        className="
  mb-16
  grid
  gap-6
  md:grid-cols-2
  max-w-3xl
"
      >

        

        <DashboardCard
          title="Products"
          count={productCount}
          subtitle="Products"
          href="#products"
          icon={ShoppingCart}
          bgColor="bg-emerald-100"
          iconColor="text-emerald-600"
          numberColor="text-emerald-600"
        />

        <DashboardCard
          title="Courses"
          count={courseCount}
          subtitle="Courses"
          href="#courses"
          icon={GraduationCap}
          bgColor="bg-violet-100"
          iconColor="text-violet-600"
          numberColor="text-violet-600"
        />

        

      </div>


      <section id="products" className="scroll-mt-28">
        <ProductTable
          onAddProduct={() => setAddProductOpen(true)}
        />
      </section>

      <AddProductDialog
        open={addProductOpen}
        onOpenChange={setAddProductOpen}
      >

        <ProductForm
          name={name}
          setName={setName}
          category={category}
          setCategory={setCategory}
          price={price}
          setPrice={setPrice}
          description={description}
          setDescription={setDescription}
          longDescription={longDescription}
          setLongDescription={setLongDescription}
          productFiles={productFiles}
          setProductFiles={setProductFiles}
          onSubmit={handleAddProduct}
          submitText="Add Product"
          loading={addingProduct}
        />

      </AddProductDialog>

        <section id="courses" className="mt-16 scroll-mt-28">
          <CourseTable
            onAddCourse={() => setAddCourseOpen(true)}
          />
        </section>

        <AddCourseDialog
          open={addCourseOpen}
          onOpenChange={setAddCourseOpen}
        >
          <CourseForm
            courseName={courseName}
            setCourseName={setCourseName}
            courseLevel={courseLevel}
            setCourseLevel={setCourseLevel}
            courseDuration={courseDuration}
            setCourseDuration={setCourseDuration}
            courseDescription={courseDescription}
            setCourseDescription={setCourseDescription}
            setCourseLongDescription={setCourseLongDescription}
            courseLongDescription={courseLongDescription}
            courseFile={courseFile}
            setCourseFile={setCourseFile}
            onAddCourse={handleAddCourse}
            loading={addingCourse}
          />
        </AddCourseDialog>

    </main>

  </SiteLayout>
  );
}