"use client";

import { useUserRole } from "@/hooks/use-user-role";
import { useAuth } from "@/hooks/use-auth";
import { signOut } from "firebase/auth";
import { auth, db } from "@/firebase/firebase";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  useEffect,
  useRef,
  useState,
} from "react";
import {
  doc,
  onSnapshot,
} from "firebase/firestore";
import { Menu, X } from "lucide-react";

interface SavedAccount {
  uid: string;
  username: string;
  email: string;
}

export default function Navbar() {

  const { user } = useAuth();

  const role =
  useUserRole();

  const router = useRouter();

  const [username,
    setUsername] =
    useState("");

  const [menuOpen,
    setMenuOpen] =
    useState(false);

  const [navMenuOpen,
    setNavMenuOpen] =
    useState(false);

  const [scrolled,
    setScrolled] =
    useState(false);

  const [savedAccounts,
    setSavedAccounts] =
    useState<SavedAccount[]>([]);

  const menuRef =
    useRef<HTMLDivElement>(null);

  const navMenuRef =
    useRef<HTMLDivElement>(null);

  useEffect(() => {

    if (!user) return;

    const unsubscribe =
      onSnapshot(
        doc(
          db,
          "users",
          user.uid
        ),
        (userDoc) => {

          if (
            userDoc.exists()
          ) {

            setUsername(
              userDoc.data()
                .username || ""
            );

          }

          const accounts =
            JSON.parse(
              localStorage.getItem(
                "notarcAccounts"
              ) || "[]"
            );

          setSavedAccounts(
            accounts
          );

        }
      );

    return () =>
      unsubscribe();

  }, [user]);

  useEffect(() => {

    function handleScroll() {

      setScrolled(
        window.scrollY > 50
      );

    }

    window.addEventListener(
      "scroll",
      handleScroll
    );

    return () =>
      window.removeEventListener(
        "scroll",
        handleScroll
      );

  }, []);

  useEffect(() => {

    function handleClickOutside(
      event: MouseEvent
    ) {

      if (
        menuRef.current &&
        !menuRef.current.contains(
          event.target as Node
        )
      ) {
        setMenuOpen(false);
      }

      if (
        navMenuRef.current &&
        !navMenuRef.current.contains(
          event.target as Node
        )
      ) {
        setNavMenuOpen(false);
      }

    }

    document.addEventListener(
      "mousedown",
      handleClickOutside
    );

    return () =>
      document.removeEventListener(
        "mousedown",
        handleClickOutside
      );

  }, []);

  function removeSavedAccount(
    uid: string
  ) {

    const updatedAccounts =
      savedAccounts.filter(
        (account) =>
          account.uid !== uid
      );

    localStorage.setItem(
      "notarcAccounts",
      JSON.stringify(
        updatedAccounts
      )
    );

    setSavedAccounts(
      updatedAccounts
    );

  }

  async function handleLogout() {

    await signOut(auth);

  }

  return (

    <header
      className={`
        sticky
        top-0
        z-50
        w-full
        border-b
        border-white/[0.08]
        bg-black/90
        backdrop-blur-xl
        transition-all
        duration-300
        ${
          scrolled
            ? "bg-black/90 shadow-[0_8px_30px_rgba(0,0,0,0.25)]"
            : "bg-black/70"
        }
      `}
    >

      <div
        className={`
          mx-auto
          flex
          max-w-7xl
          items-center
          justify-between
          pl-0
          pr-6
          md:px-6
          transition-all
          duration-300
          ${
            scrolled
              ? "h-16"
              : "h-20"
          }
        `}
      >

        <Link
          href="/"
          onClick={(e) => {
            if (window.location.pathname === "/") {
              e.preventDefault();

              window.scrollTo({
                top: 0,
                behavior: "smooth",
              });
            }
          }}
          className="shrink-0 md:-translate-x-28"
        >
          <div
            className={`
              relative
              overflow-hidden
              transition-all
              duration-300
              ${
                scrolled
                  ? "h-11 w-36"
                  : "h-12 w-40"
              }
            `}
          >
            <Image
              src="/ntrclogo.png"
              alt="NOTARC"
              fill
              priority
              sizes="160px"
              className="object-cover object-center"
            />
          </div>
        </Link>

        <nav
          className="
            hidden
            md:flex
            items-center
            gap-1
            rounded-full
            border
            border-white/[0.08]
            bg-white/[0.04]
            p-1
            text-sm
            font-medium
          "
        >

          <Link
            href="/"
            className="
              rounded-full
              px-4
              py-2
              text-white/75
              transition-all
              duration-300
              ease-out
              hover:bg-white/10
              hover:text-white
              hover:-translate-y-0.5
              hover:shadow-[0_0_16px_rgba(255,255,255,0.08)]
              active:translate-y-0
            "
          >
            Home
          </Link>

          <Link
            href="/products"
            className="
              rounded-full
              px-4
              py-2
              text-white/75
              transition-all
              duration-300
              ease-out
              hover:bg-white/10
              hover:text-white
              hover:-translate-y-0.5
              hover:shadow-[0_0_16px_rgba(255,255,255,0.08)]
              active:translate-y-0
            "
          >
            Explore Products
          </Link>

          <Link
            href="/courses"
            className="
              rounded-full
              px-4
              py-2
              text-white/75
              transition-all
              duration-300
              ease-out
              hover:bg-white/10
              hover:text-white
              hover:-translate-y-0.5
              hover:shadow-[0_0_16px_rgba(255,255,255,0.08)]
              active:translate-y-0
            "
          >
            Book a Course
          </Link>

          <Link
            href="/contact-us"
            className="
              rounded-full
              px-4
              py-2
              text-white/75
              transition-all
              duration-300
              ease-out
              hover:bg-white/10
              hover:text-white
              hover:-translate-y-0.5
              hover:shadow-[0_0_16px_rgba(255,255,255,0.08)]
              active:translate-y-0
            "
          >
            Contact Us
          </Link>

          <Link
            href="/cart"
            className="
              rounded-full
              px-4
              py-2
              text-white/75
              transition-all
              duration-300
              ease-out
              hover:bg-white/10
              hover:text-white
              hover:-translate-y-0.5
              hover:shadow-[0_0_16px_rgba(255,255,255,0.08)]
              active:translate-y-0
            "
          >
            Cart
          </Link>

        </nav>

        {/* Mobile hamburger nav — works regardless of login state */}
        <div
          ref={navMenuRef}
          className="relative md:hidden"
        >

          <button
            onClick={() =>
              setNavMenuOpen(
                !navMenuOpen
              )
            }
            aria-label={
              navMenuOpen
                ? "Close navigation menu"
                : "Open navigation menu"
            }
            className="
              flex
              h-10
              w-10
              items-center
              justify-center
              rounded-full
              border
              border-white/10
              bg-white/[0.04]
              text-white
              transition
              hover:bg-white/10
            "
          >
            {navMenuOpen ? (
              <X className="h-5 w-5" />
            ) : (
              <Menu className="h-5 w-5" />
            )}
          </button>

          {navMenuOpen && (

            <div
              className="
                absolute
                right-0
                mt-2
                w-56
                overflow-hidden
                rounded-2xl
                border
                border-white/10
                bg-black/90
                text-white
                shadow-2xl
                shadow-black/40
                backdrop-blur-xl
                z-50
              "
            >

              <Link
                href="/"
                onClick={() => setNavMenuOpen(false)}
                className="block px-4 py-2.5 text-sm hover:bg-white/10"
              >
                Home
              </Link>

              <Link
                href="/products"
                onClick={() => setNavMenuOpen(false)}
                className="block px-4 py-2.5 text-sm hover:bg-white/10"
              >
                Explore Products
              </Link>

              <Link
                href="/courses"
                onClick={() => setNavMenuOpen(false)}
                className="block px-4 py-2.5 text-sm hover:bg-white/10"
              >
                Book a Course
              </Link>

              <Link
                href="/contact-us"
                onClick={() => setNavMenuOpen(false)}
                className="block px-4 py-2.5 text-sm hover:bg-white/10"
              >
                Contact Us
              </Link>

              <Link
                href="/cart"
                onClick={() => setNavMenuOpen(false)}
                className="block px-4 py-2.5 text-sm hover:bg-white/10"
              >
                Cart
              </Link>

            </div>

          )}

        </div>

        {user ? (

          <div
            ref={menuRef}
            className="relative"
          >

            <button
              onClick={() =>
                setMenuOpen(
                  !menuOpen
                )
              }
              className="
                flex
                items-center
                gap-3
                rounded-full
                border
                border-white/10
                bg-white/[0.08]
                px-2
                py-2
                text-white
                shadow-lg
                shadow-black/10
                backdrop-blur-sm
                transition-all
                duration-200
                hover:border-white/20
                hover:bg-white/[0.14]
                hover:scale-[1.02]
              "
            >

              <div
                className="
                  flex
                  h-9
                  w-9
                  items-center
                  justify-center
                  rounded-full
                  bg-white
                  text-sm
                  font-bold
                  text-black
                  shadow-sm
                "
              >
                {(username ||
                  user.email ||
                  "U")
                  .charAt(0)
                  .toUpperCase()}
              </div>

              <span className="max-w-32 truncate text-sm font-medium text-white/90">
                {username ||
                  user.email}
              </span>

              <span
                className={`
                  text-xs
                  text-white/60
                  transition-transform
                  duration-200
                  ${
                    menuOpen
                      ? "rotate-180"
                      : ""
                  }
                `}
              >
                ▼
              </span>

            </button>

            {menuOpen && (

              <div
                className="
                  absolute
                  right-0
                  mt-2
                  w-64 sm:w-72
                  overflow-hidden
                  rounded-2xl
                  border
                  border-white/10
                  bg-black/90
                  text-white
                  shadow-2xl
                  shadow-black/40
                  backdrop-blur-xl
                  z-50
                "
              >

                <div className="border-b border-white/10 px-4 py-3 sm:px-5 sm:py-4">

                  <p className="font-semibold text-base sm:text-lg">
                    {username}
                  </p>

                  <p className="truncate text-sm text-white/50">
                    {user.email}
                  </p>

                </div>

                <Link
                  href="/profile"
                  className="block px-4 py-2.5 sm:px-5 sm:py-3 hover:bg-white/10"
                >
                  Profile
                </Link>

                <Link
                  href="/my-courses"
                  className="block px-4 py-2.5 sm:px-5 sm:py-3 hover:bg-white/10"
                >
                  My Courses
                </Link>

                <Link
                  href="/my-orders"
                  className="block px-4 py-2.5 sm:px-5 sm:py-3 hover:bg-white/10"
                >
                  My Orders
                </Link>

                {role === "admin" && (

                  <Link
                    href="/admin"
                    className="
                      block
                      px-4
                      py-2.5
                      sm:py-3
                      transition
                      hover:bg-white/10
                    "
                  >
                    Dashboard
                  </Link>

                )}

                <hr className="border-white/10" />

                <div className="px-4 py-2.5 sm:px-5 sm:py-3">

                  <p
                    className="
                      mb-3
                      text-xs
                      font-semibold
                      uppercase
                      tracking-wider
                      text-white/40
                    "
                  >
                    Accounts
                  </p>
                
                  {savedAccounts.map(
                    (account) => (

                      <div
                        key={account.uid}
                        className={`
                          mb-2
                          flex
                          items-center
                          justify-between
                          rounded-xl
                          transition
                          hover:bg-white/10
                          ${
                            account.uid === user.uid
                              ? "bg-white/10"
                              : ""
                          }
                        `}
                      >

                        <button
                          onClick={() => {

                            if (
                              account.uid ===
                              user.uid
                            ) {
                              return;
                            }

                            localStorage.setItem(
                              "notarcSelectedAccount",
                              JSON.stringify(
                                account
                              )
                            );

                            setMenuOpen(false);

                            router.push(
                              "/login"
                            );

                          }}
                          className="
                            flex
                            flex-1
                            items-center
                            gap-3
                            p-2
                            text-left
                          "
                        >

                          <div className="relative">

                            <div
                              className="
                                flex
                                h-10
                                w-10
                                items-center
                                justify-center
                                rounded-full
                                bg-slate-900
                                text-white
                                font-bold
                              "
                            >
                              {account.username
                                .charAt(0)
                                .toUpperCase()}
                            </div>

                            {account.uid ===
                              user.uid && (

                              <div
                                className="
                                  absolute
                                  -bottom-0.5
                                  -right-0.5
                                  h-3
                                  w-3
                                  rounded-full
                                  border-2
                                  border-white
                                  bg-green-500
                                "
                              />

                            )}

                          </div>

                          <div>

                            <p
                              className="
                                font-medium
                                text-white
                              "
                            >
                              {account.username}
                            </p>

                            <p
                              className="
                                text-xs
                                text-white/50
                              "
                            >
                              {account.email}
                            </p>

                          </div>

                        </button>

                        <button
                          onClick={() => {

                            if (
                              account.uid === user.uid
                            ) {
                              return;
                            }

                            removeSavedAccount(
                              account.uid
                            );

                          }}
                          className="
                            mr-2
                            flex
                            h-8
                            w-8
                            items-center
                            justify-center
                            rounded-full
                            text-slate-400
                            transition
                            hover:bg-red-100
                            hover:text-red-600
                            disabled:cursor-not-allowed
                            disabled:opacity-40
                          "
                          disabled={
                            account.uid === user.uid
                          }
                          title={
                            account.uid === user.uid
                              ? "Current account"
                              : "Remove account"
                          }
                        >
                          ✕
                        </button>

                      </div>

                    )
                  )}

                  <Link
                    href="/login"
                    onClick={() => {

                      localStorage.removeItem(
                        "notarcSelectedAccount"
                      );

                      setMenuOpen(false);

                    }}
                    className="
                      mt-3
                      block
                      rounded-xl
                      border
                      border-white/10
                      px-3
                      py-2
                      text-center
                      text-white/70
                      transition
                      hover:bg-white/10
                      hover:text-white
                    "
                  >
                    + Add another account
                  </Link>

                </div>

                <hr className="border-white/10" />

                <button
                  onClick={
                    handleLogout
                  }
                  className="
                    block
                    w-full
                    px-4
                    py-3
                    sm:px-5
                    sm:py-4
                    text-left
                    font-medium
                    text-red-600
                    transition
                    hover:bg-red-500/10
                  "
                >
                  Logout
                </button>

              </div>

            )}

          </div>

        ) : (

          <div className="flex items-center gap-2">

            <Link
              href="/login"
              className="
                rounded-full
                px-4
                py-2
                text-sm
                font-medium
                text-white/80
                transition-all
                duration-200
                hover:bg-white/10
                hover:text-white
              "
            >
              Login
            </Link>

            <Link
              href="/signup"
              className="
                rounded-full
                bg-white
                px-5
                py-2.5
                text-sm
                font-semibold
                text-black
                shadow-sm
                transition-all
                duration-200
                hover:bg-blue-500
                hover:text-white
                hover:shadow-lg
                hover:shadow-blue-500/20
              "
            >
              Signup
            </Link>

          </div>

        )}

      </div>

    </header>

  );

}